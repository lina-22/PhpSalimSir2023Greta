<?php

class InscrireDAO
{

    static function  ajouterEleveCours($idCours, $IdEleve, $dateInscription)
    {

        $sql = PdoMusic::getMonPdo()->prepare("INSERT INTO `inscrire`(`idCours`, `IdEleve`, `dateInscription`) VALUES (:IDCOURS,:IDELEVE,:DATEINSCRIPTION)");
        $sql->bindValue(":IDCOURS", $idCours);
        $sql->bindValue(":IDELEVE", $IdEleve);
        $sql->bindValue(":DATEINSCRIPTION", $dateInscription);
        $resultat = $sql->execute();
        return $resultat;
    }




    //public static  function getLesSeances()
    public static  function getLesInscriptions()
    {

        try {
            $inscrires = array();

            $req = "Select * from inscrire";

            $monPdoMusic = PdoMusic::getPdoMusic();

            $rs = $monPdoMusic::getMonPdo()->prepare($req);

            $rs->setFetchMode(PDO::FETCH_OBJ);

            $rs->execute();

            $inscrires = $rs->fetchAll();
            return $inscrires;
        } catch (PDOException $e) {

            echo 'Échec lors de la connexion : ' . $e->getMessage();
        }
    }
}
