<div id="contenu" style="display:inline-table;">
    <div>
        <h3>« voirInscriptions »</h3>
    </div>
    <?php
    foreach ($lesInscriptions as $unInscriptions) {


        //echo "Cours <b>$numero</b> <br>";

        echo " <b>***************</b> <br>";
        echo "idCour est " . $unInscriptions->idCours . " <br>";
        echo "idEleve est " . $unInscriptions->IdEleve . "</br>";
        echo "dateInscription est " . $unInscriptions->dateInscription . "</br>";
        // var_dump($unCours);
        echo " <b>*****************</b> <br>";
        echo " <br> <br>";
    }
    ?>
</div>
<!-- $idCours, $IdEleve, $dateInscription -->