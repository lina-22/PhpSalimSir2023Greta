<div id="cont">
    <?php

    echo "La réservation  est confirmée
pour l'adhérent $prenom  $nom .";

    ?>
</div>