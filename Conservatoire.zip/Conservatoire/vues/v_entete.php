<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<!-- TITRE ET MENUS -->
<html lang="fr">

<head>
	<title>Projet ZiqMu</title>
	<meta http-equiv="Content-Language" content="fr">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	<link href="css/cssGeneral.css" rel="stylesheet" type="text/css">


</head>

<body>

	<div id="bandeau">
		<!-- Images En-tête -->
		<img src="images/conservatoire.jpg" alt="conservatoire" title="conservatoire" />
	</div>
	<!--  Menu haut-->
	<ul id="menu">
		<li><a href="index.php?action=accueil"> Accueil </a></li>
		<li><a href="index.php?action=voirCours"> Voir le catalogue des cours</a></li>
		<li><a href="index.php?action=voirInscriptions"> Voir les inscriptions</a></li>
	</ul>


	<div id="contenu">
		<!-- Images En-tête -->

	</div>


	<div id="contenu1">




	</div>